﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_
{

    class Student
    { 
        public int Id { get; set; }
        public string Name { get; set; }
    }
    class Enrollment
    {
        public int Id { get; set; }
        public int StudentId { get; set; }
        public string Course { get; set; }
    }
    internal class StudentEnrollment
    {
        
        public static void Main(string[] args)
        {
            List<Student> students = new List<Student>
        {
            new Student{Id=1, Name="Jaswanth"},
            new Student{Id=2, Name="Jaswanth2"},
            new Student{Id=3, Name="Jaswanth3"},
        };
            List<Enrollment> enrollments = new List<Enrollment>
        {
            new Enrollment{Id=1, StudentId=1, Course="Math"},
            new Enrollment{Id=2, StudentId=3, Course="Science"},
            new Enrollment{Id=3, StudentId=2, Course="Social"},
            new Enrollment{Id=4, StudentId=3, Course="Telugu"},
        };
            var result = from student in students
                         join enrollment in enrollments
                         on student.Id equals enrollment.StudentId
                         select new
                         {
                             StudentName = student.Name,
                             Course = enrollment.Course
                         };
            foreach(var item in result)
            {
                Console.WriteLine(item.StudentName + " " + item.Course);
            }
        }
    }
    
}
